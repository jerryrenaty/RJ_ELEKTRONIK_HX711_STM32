/**
 * ******************************************************************************
 * @file    RJ_ELEKTRONIK_HX711_STM32.c
 * @brief   Version Finale Optimisée et Stabilisée du driver HX711 pour STM32
 * ******************************************************************************
 */
#include "RJ_ELEKTRONIK_HX711_STM32.h"

// Fonction de micro-délai matérielle et robuste pour bloquer le CPU le temps requis
static void HX711_HardwareDelayUs(uint32_t us) {
    // Équivalent d'un délai microseconde robuste sans optimisations du compilateur
    volatile uint32_t cycles = us * (SystemCoreClock / 2000000);
    while (cycles--) {
        __NOP();
    }
}
#define HX711_DELAY() HX711_HardwareDelayUs(5) // On force une pause de 5 microsecondes (Tranquillité absolue)


void HX711_Init(HX711_HandleTypeDef *hx711, HX711_Gain initial_gain) {
    // Assignation automatique des ports et broches via vos macros globales
    hx711->gpio.CLK_GPIOx = SCK_GPIO_Port;
    hx711->gpio.CLK_GPIO_Pin = SCK_Pin;
    hx711->gpio.DT_GPIOx = DT_GPIO_Port;
    hx711->gpio.DT_GPIO_Pin = DT_Pin;

    // Initialisation des structures de données de base
    hx711->calibration_factor = 91.07f;
    hx711->offset = 0;
    hx711->last_raw_value = 0;
    hx711->last_weight = 0.0f;
    hx711->gain = initial_gain;

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // CONFIGURATION SCK : Sortie Push-Pull standard
    HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_RESET);
    GPIO_InitStruct.Pin = hx711->gpio.CLK_GPIO_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(hx711->gpio.CLK_GPIOx, &GPIO_InitStruct);

    // CONFIGURATION DT : Entrée avec résistance de tirage (Pull-Up) pour stabiliser le signal
    GPIO_InitStruct.Pin = hx711->gpio.DT_GPIO_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(hx711->gpio.DT_GPIOx, &GPIO_InitStruct);
}

int32_t HX711_Read(HX711_HandleTypeDef *hx711) {
    int32_t data = 0;
    uint32_t timeout = 500000;

    // Attente matérielle active : On attend que DT descende à LOW (Donnée prête)
    while (HAL_GPIO_ReadPin(hx711->gpio.DT_GPIOx, hx711->gpio.DT_GPIO_Pin) == GPIO_PIN_SET) {
        if (--timeout == 0) return 0;
    }

    // Protection temporelle critique : Désactivation des interruptions
    __disable_irq();

    // Lecture des 24 bits de données du protocole synchrone
    for (uint8_t i = 0; i < 24; i++) {
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_SET);
        HX711_DELAY();
        
        data <<= 1; // Décalage logique correct avant d'enregistrer l'état électrique
        if (HAL_GPIO_ReadPin(hx711->gpio.DT_GPIOx, hx711->gpio.DT_GPIO_Pin) == GPIO_PIN_SET) {
            data |= 1;
        }
        
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_RESET);
        HX711_DELAY();
    }

    // Impulsions supplémentaires obligatoires pour définir le gain du prochain cycle
    for (uint8_t i = 0; i < (uint8_t)hx711->gain; i++) {
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_SET);
        HX711_DELAY();
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_RESET);
        HX711_DELAY();
    }

    // Réactivation des interruptions dès la fin de l'échange synchrone
    __enable_irq();

    // Extension de signe de 24 bits vers 32 bits (Complément à 2 conforme)
    if (data & 0x800000) {
        data |= 0xFF000000;
    }

    hx711->last_raw_value = data;
    return data;
}

void HX711_Tare(HX711_HandleTypeDef *hx711, uint8_t samples) {
    int64_t sum = 0;

    // Échantillon "à vide" jetable pour purger les anciens registres du capteur
    HX711_Read(hx711);

    // Somme directe sans aucun HAL_Delay artificiel perturbateur
    for (uint8_t i = 0; i < samples; i++) {
        sum += HX711_Read(hx711);
    }
    hx711->offset = (int32_t)(sum / samples);
}

float HX711_GetWeightGram(HX711_HandleTypeDef *hx711, uint8_t samples) {
    int64_t sum = 0;

    // Somme directe gérée par le rythme natif du HX711 (10Hz ou 80Hz)
    for (uint8_t i = 0; i < samples; i++) {
        sum += HX711_Read(hx711);
    }
    hx711->last_raw_value = (int32_t)(sum / samples);
    hx711->last_weight = (float)(hx711->last_raw_value - hx711->offset) / hx711->calibration_factor;
    
    return hx711->last_weight;
}

void HX711_SetGain(HX711_HandleTypeDef *hx711, HX711_Gain new_gain) {
    hx711->gain = new_gain;
    HX711_Read(hx711); 
}
