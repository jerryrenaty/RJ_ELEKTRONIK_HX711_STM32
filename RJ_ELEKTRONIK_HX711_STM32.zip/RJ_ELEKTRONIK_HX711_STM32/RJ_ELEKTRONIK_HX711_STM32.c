/**
 * ******************************************************************************
 * @file    RJ_ELEKTRONIK_HX711_STM32.c
 * @brief   Implémentation corrigée du driver HX711
 * ******************************************************************************
 */
#include "RJ_ELEKTRONIK_HX711_STM32.h"

// Délai matériel minimal requis par le protocole HX711
#define HX711_DELAY() __NOP(); __NOP(); __NOP(); __NOP()

void HX711_Init(HX711_HandleTypeDef *hx711, GPIO_TypeDef* CLK_GPIOx, uint16_t CLK_GPIO_Pin, GPIO_TypeDef* DT_GPIOx, uint16_t DT_GPIO_Pin, HX711_Gain initial_gain) {
    hx711->gpio.CLK_GPIOx = CLK_GPIOx;
    hx711->gpio.CLK_GPIO_Pin = CLK_GPIO_Pin;
    hx711->gpio.DT_GPIOx = DT_GPIOx;
    hx711->gpio.DT_GPIO_Pin = DT_GPIO_Pin;

    HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_RESET);

    hx711->calibration_factor = 1.0f; // Initialisé à 1 pour éviter la division par zéro
    hx711->offset = 0;
    hx711->last_raw_value = 0;
    hx711->last_weight = 0.0f;
    hx711->gain = initial_gain;

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = hx711->gpio.DT_GPIO_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(hx711->gpio.DT_GPIOx, &GPIO_InitStruct);
}

int32_t HX711_Read(HX711_HandleTypeDef *hx711) {
    int32_t data = 0;
    uint32_t timeout = 100000;

    // Attente que le HX711 soit prêt (DT passe à LOW)
    while (HAL_GPIO_ReadPin(hx711->gpio.DT_GPIOx, hx711->gpio.DT_GPIO_Pin) == GPIO_PIN_SET) {
        if (--timeout == 0) return 0;
    }

    // Lecture des 24 bits de données
    for (uint8_t i = 0; i < 24; i++) {
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_SET);
        HX711_DELAY();
        data <<= 1;
        if (HAL_GPIO_ReadPin(hx711->gpio.DT_GPIOx, hx711->gpio.DT_GPIO_Pin) == GPIO_PIN_SET) {
            data |= 1;
        }
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_RESET);
        HX711_DELAY();
    }

    // CORRECTION : Impulsions supplémentaires selon l'énumération (1, 2 ou 3 pulses)
    for (uint8_t i = 0; i < (uint8_t)hx711->gain; i++) {
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_SET);
        HX711_DELAY();
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_RESET);
        HX711_DELAY();
    }

    // Extension de signe pour le format 24 bits complément à 2
    if (data & 0x800000) {
        data |= 0xFF000000;
    }

    hx711->last_raw_value = data;
    return data;
}

void HX711_Tare(HX711_HandleTypeDef *hx711, uint8_t samples) {
    int64_t sum = 0;
    for (uint8_t i = 0; i < samples; i++) {
        sum += HX711_Read(hx711);
        HAL_Delay(10); // Temps de conversion du HX711 (10Hz ou 80Hz)
    }
    hx711->offset = (int32_t)(sum / samples);
}

float HX711_GetWeightGram(HX711_HandleTypeDef *hx711, uint8_t samples) {
    int64_t sum = 0;
    for (uint8_t i = 0; i < samples; i++) {
        sum += HX711_Read(hx711);
        HAL_Delay(10);
    }
    hx711->last_raw_value = (int32_t)(sum / samples);
    hx711->last_weight = (float)(hx711->last_raw_value - hx711->offset) / hx711->calibration_factor;
    
    // CORRECTION : Suppression du blocage à 0.0f pour autoriser les valeurs négatives
    return hx711->last_weight;
}

void HX711_SetGain(HX711_HandleTypeDef *hx711, HX711_Gain new_gain) {
    hx711->gain = new_gain;
    HX711_Read(hx711); // Applique la configuration matériellement
}
