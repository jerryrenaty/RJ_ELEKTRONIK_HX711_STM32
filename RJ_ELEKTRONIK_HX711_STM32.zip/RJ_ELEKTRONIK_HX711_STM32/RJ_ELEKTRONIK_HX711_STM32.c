/**
  ******************************************************************************
  * @file    hx711.c
  * @author  RJ_ELEKTRONIK
  * Created on: Apr 5, 2025
  * @brief   Implémentation du driver HX711
  ******************************************************************************
  */

#include "RJ_ELEKTRONIK_HX711_STM32.h"

// Macro pour un petit délai entre les pulses SCK
#define HX711_DELAY() __NOP(); __NOP(); __NOP(); __NOP()

/**
  * @brief  Initialise le module HX711
  * @param  hx711: Pointeur vers la structure de gestion du HX711
  * @param  CLK_GPIOx: Port GPIO pour la broche CLK (horloge)
  * @param  CLK_GPIO_Pin: Pin GPIO pour la broche CLK (horloge)
  * @param  DT_GPIOx: Port GPIO pour la broche DT (données)
  * @param  DT_GPIO_Pin: Pin GPIO pour la broche DT (données)
  * @param  initial_gain: Gain initial à configurer (128, 64 ou 32)
  * @retval None
  */
void HX711_Init(HX711_HandleTypeDef *hx711,
                GPIO_TypeDef* CLK_GPIOx, uint16_t CLK_GPIO_Pin,
                GPIO_TypeDef* DT_GPIOx, uint16_t DT_GPIO_Pin,
                HX711_Gain initial_gain) {

    // Configuration des GPIO
    hx711->gpio.CLK_GPIOx = CLK_GPIOx;
    hx711->gpio.CLK_GPIO_Pin = CLK_GPIO_Pin;
    hx711->gpio.DT_GPIOx = DT_GPIOx;
    hx711->gpio.DT_GPIO_Pin = DT_GPIO_Pin;

    // Initialisation hardware - mise à 0 de la broche CLK
    HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_RESET);

    // Configuration par défaut
    hx711->calibration_factor = 1000.0f;  // Facteur de calibration par défaut
    hx711->offset = 0;                   // Offset initial à 0
    hx711->last_raw_value = 0;           // Dernière valeur brute lue
    hx711->last_weight = 0.0f;           // Dernier poids calculé
    hx711->gain = initial_gain;          // Gain initial

    // Configuration de la broche DATA en entrée
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = hx711->gpio.DT_GPIO_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;  // Mode entrée
    GPIO_InitStruct.Pull = GPIO_NOPULL;      // Pas de résistance de pull-up/pull-down
    HAL_GPIO_Init(hx711->gpio.DT_GPIOx, &GPIO_InitStruct);
}

/**
  * @brief  Lit une valeur brute depuis le HX711
  * @param  hx711: Pointeur vers la structure de gestion du HX711
  * @retval Valeur brute 24 bits signée (complément à 2)
  */
int32_t HX711_Read(HX711_HandleTypeDef *hx711) {
    int32_t data = 0;
    uint32_t timeout = 100000;  // Timeout pour éviter les blocages

    // Attente que le HX711 soit prêt (broche DATA passe à LOW)
    while (HAL_GPIO_ReadPin(hx711->gpio.DT_GPIOx, hx711->gpio.DT_GPIO_Pin) == GPIO_PIN_SET) {
        if (--timeout == 0) return 0;  // Retourne 0 en cas de timeout
    }

    // Lecture des 24 bits de données
    for (uint8_t i = 0; i < 24; i++) {
        // Pulse sur CLK pour lire le bit suivant
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_SET);
        HX711_DELAY();

        // Décale les bits et lit la valeur courante
        data <<= 1;
        if (HAL_GPIO_ReadPin(hx711->gpio.DT_GPIOx, hx711->gpio.DT_GPIO_Pin) == GPIO_PIN_SET) {
            data |= 1;  // Met le bit à 1 si la broche DATA est HIGH
        }

        // Fin du pulse CLK
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_RESET);
        HX711_DELAY();
    }

    // Configuration du gain avec des pulses supplémentaires sur CLK
    for (uint8_t i = 0; i < hx711->gain; i++) {
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_SET);
        HX711_DELAY();
        HAL_GPIO_WritePin(hx711->gpio.CLK_GPIOx, hx711->gpio.CLK_GPIO_Pin, GPIO_PIN_RESET);
        HX711_DELAY();
    }

    // Conversion en complément à 2 pour les valeurs négatives (bit 23 à 1)
    if (data & 0x800000) {
        data |= 0xFF000000;  // Étend le signe sur 32 bits
    }

    // Sauvegarde de la valeur brute lue
    hx711->last_raw_value = data;
    return data;
}

/**
  * @brief  Effectue une tare (mise à zéro) du capteur
  * @param  hx711: Pointeur vers la structure de gestion du HX711
  * @param  samples: Nombre d'échantillons à moyenner pour la tare
  * @retval None
  */
void HX711_Tare(HX711_HandleTypeDef *hx711, uint8_t samples) {
    int64_t sum = 0;

    // Acquisition de plusieurs échantillons pour calculer une moyenne
    for (uint8_t i = 0; i < samples; i++) {
        sum += HX711_Read(hx711);
        HAL_Delay(5);  // Petit délai entre les lectures
    }

    // Calcul et sauvegarde de l'offset moyen
    hx711->offset = (int32_t)(sum / samples);
}

/**
  * @brief  Obtient le poids en grammes
  * @param  hx711: Pointeur vers la structure de gestion du HX711
  * @param  samples: Nombre d'échantillons à moyenner
  * @retval Poids calculé en grammes
  */
float HX711_GetWeightGram(HX711_HandleTypeDef *hx711, uint8_t samples) {
    int64_t sum = 0;

    // Acquisition de plusieurs échantillons pour lissage
    for (uint8_t i = 0; i < samples; i++) {
        sum += HX711_Read(hx711);
        HAL_Delay(5);  // Petit délai entre les lectures
    }

    // Calcul de la moyenne et application du facteur de calibration
    hx711->last_raw_value = (int32_t)(sum / samples);
    hx711->last_weight = (hx711->last_raw_value - hx711->offset) / hx711->calibration_factor;

    // Le poids ne peut pas être négatif
    if (hx711->last_weight < 0) hx711->last_weight = 0.0f;

    return hx711->last_weight;
}

/**
  * @brief  Change le gain du HX711
  * @param  hx711: Pointeur vers la structure de gestion du HX711
  * @param  new_gain: Nouveau gain à appliquer (128, 64 ou 32)
  * @retval None
  */
void HX711_SetGain(HX711_HandleTypeDef *hx711, HX711_Gain new_gain) {
    hx711->gain = new_gain;
    // Une lecture est nécessaire pour appliquer le nouveau gain
    HX711_Read(hx711);
}
