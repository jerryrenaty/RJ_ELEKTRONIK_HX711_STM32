/**
  ******************************************************************************
  * @file    hx711.h
  * @author  RJ_ELEKTRONIK
  * Created on: Apr 5, 2025
  * @brief   Driver pour le module HX711 (capteur de poids)
  *
  * Ce fichier contient les définitions pour le driver du module HX711,
  * un convertisseur analogique-numérique 24 bits pour cellules de charge.
  ******************************************************************************
  */
#ifndef INC_RJ_ELEKTRONIK_HX711_H_
#define INC_RJ_ELEKTRONIK_HX711_H_

#include "stm32f1xx_hal.h"  // Inclusion de la HAL STM32F1

/**
  * @brief  Enumération des gains disponibles pour le HX711
  * @note   Le gain détermine la sensibilité et le canal utilisé:
  *         - Gain 128: Canal A, meilleure sensibilité
  *         - Gain 64: Canal B
  *         - Gain 32: Canal A, plage dynamique étendue
  */
typedef enum {
    HX711_GAIN_128 = 1,  // Canal A - Gain 128 (par défaut)
    HX711_GAIN_64 = 3,   // Canal B - Gain 64
    HX711_GAIN_32 = 2    // Canal A - Gain 32
} HX711_Gain;

/**
  * @brief  Structure de configuration des broches GPIO
  * @note   Contient les paramètres pour les broches CLK (horloge) et DT (données)
  */
typedef struct {
    GPIO_TypeDef* CLK_GPIOx;   // Port GPIO pour la broche SCK/CLK (horloge)
    uint16_t CLK_GPIO_Pin;     // Numéro de pin pour SCK/CLK
    GPIO_TypeDef* DT_GPIOx;    // Port GPIO pour la broche DATA/DT (données)
    uint16_t DT_GPIO_Pin;      // Numéro de pin pour DATA/DT
} HX711_GPIO_Config;

/**
  * @brief  Structure principale de gestion du HX711
  * @note   Contient tous les paramètres nécessaires au fonctionnement du capteur
  */
typedef struct {
    HX711_GPIO_Config gpio;      // Configuration des broches GPIO
    float calibration_factor;    // Facteur pour convertir les valeurs brutes en poids (valeur brute/gramme)
    int32_t offset;             // Valeur de tare (offset) pour la mise à zéro
    int32_t last_raw_value;     // Dernière valeur brute lue (24 bits signé)
    float last_weight;          // Dernier poids calculé (en grammes)
    HX711_Gain gain;            // Gain actuellement configuré (128, 64 ou 32)
} HX711_HandleTypeDef;

/* Prototypes des fonctions ---------------------------------------------------*/

/**
  * @brief  Initialise le module HX711
  * @param  hx711: Pointeur vers la structure de gestion
  * @param  CLK_GPIOx: Port GPIO pour la broche CLK
  * @param  CLK_GPIO_Pin: Pin pour la broche CLK
  * @param  DT_GPIOx: Port GPIO pour la broche DT
  * @param  DT_GPIO_Pin: Pin pour la broche DT
  * @param  initial_gain: Gain initial à configurer
  * @retval None
  */
void HX711_Init(HX711_HandleTypeDef *hx711,
                GPIO_TypeDef* CLK_GPIOx, uint16_t CLK_GPIO_Pin,
                GPIO_TypeDef* DT_GPIOx, uint16_t DT_GPIO_Pin,
                HX711_Gain initial_gain);

/**
  * @brief  Lit une valeur brute depuis le HX711
  * @param  hx711: Pointeur vers la structure de gestion
  * @retval Valeur brute 24 bits signée (complément à 2)
  */
int32_t HX711_Read(HX711_HandleTypeDef *hx711);

/**
  * @brief  Effectue une tare (mise à zéro) du capteur
  * @param  hx711: Pointeur vers la structure de gestion
  * @param  samples: Nombre d'échantillons à moyenner pour la tare
  * @retval None
  */
void HX711_Tare(HX711_HandleTypeDef *hx711, uint8_t samples);

/**
  * @brief  Obtient le poids en grammes
  * @param  hx711: Pointeur vers la structure de gestion
  * @param  samples: Nombre d'échantillons à moyenner
  * @retval Poids calculé en grammes
  */
float HX711_GetWeightGram(HX711_HandleTypeDef *hx711, uint8_t samples);

/**
  * @brief  Change le gain du HX711
  * @param  hx711: Pointeur vers la structure de gestion
  * @param  new_gain: Nouveau gain à appliquer
  * @retval None
  */
void HX711_SetGain(HX711_HandleTypeDef *hx711, HX711_Gain new_gain);

#endif /* INC_RJ_ELEKTRONIK_HX711_H_ */
