/**
 * ******************************************************************************
 * @file    RJ_ELEKTRONIK_HX711_STM32.h
 * @brief   Header du driver HX711 corrigé pour STM32 HAL
 * ******************************************************************************
 */
#ifndef RJ_ELEKTRONIK_HX711_STM32_H_
#define RJ_ELEKTRONIK_HX711_STM32_H_

#include "stm32f4xx_hal.h" // À adapter selon votre série (ex: stm32f1xx_hal.h)

/**
 * @brief Énumération des gains supportés (valeurs = nombre d'impulsions de gain)
 */
typedef enum {
    HX711_GAIN_128 = 1, // Canal A, Gain 128
    HX711_GAIN_32  = 2, // Canal B, Gain 32
    HX711_GAIN_64  = 3  // Canal A, Gain 64
} HX711_Gain;

/**
 * @brief Structure de configuration des broches GPIO
 */
typedef struct {
    GPIO_TypeDef* CLK_GPIOx;
    uint16_t      CLK_GPIO_Pin;
    GPIO_TypeDef* DT_GPIOx;
    uint16_t      DT_GPIO_Pin;
} HX711_GPIO_Config;

/**
 * @brief Structure de gestion du module HX711
 */
typedef struct {
    HX711_GPIO_Config gpio;
    HX711_Gain        gain;
    int32_t           offset;
    float             calibration_factor;
    int32_t           last_raw_value;
    float             last_weight;
} HX711_HandleTypeDef;

// Prototypes des fonctions
void    HX711_Init(HX711_HandleTypeDef *hx711, GPIO_TypeDef* CLK_GPIOx, uint16_t CLK_GPIO_Pin, GPIO_TypeDef* DT_GPIOx, uint16_t DT_GPIO_Pin, HX711_Gain initial_gain);
int32_t HX711_Read(HX711_HandleTypeDef *hx711);
void    HX711_Tare(HX711_HandleTypeDef *hx711, uint8_t samples);
float   HX711_GetWeightGram(HX711_HandleTypeDef *hx711, uint8_t samples);
void    HX711_SetGain(HX711_HandleTypeDef *hx711, HX711_Gain new_gain);

#endif /* RJ_ELEKTRONIK_HX711_STM32_H_ */
